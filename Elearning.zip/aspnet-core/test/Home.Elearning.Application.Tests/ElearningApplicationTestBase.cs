﻿namespace Home.Elearning
{
    public abstract class ElearningApplicationTestBase : ElearningTestBase<ElearningApplicationTestModule> 
    {

    }
}
