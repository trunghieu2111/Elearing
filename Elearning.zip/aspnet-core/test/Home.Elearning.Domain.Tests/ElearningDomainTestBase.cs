﻿namespace Home.Elearning
{
    public abstract class ElearningDomainTestBase : ElearningTestBase<ElearningDomainTestModule> 
    {

    }
}
