﻿using Volo.Abp;

namespace Home.Elearning.EntityFrameworkCore
{
    public abstract class ElearningEntityFrameworkCoreTestBase : ElearningTestBase<ElearningEntityFrameworkCoreTestModule> 
    {

    }
}
