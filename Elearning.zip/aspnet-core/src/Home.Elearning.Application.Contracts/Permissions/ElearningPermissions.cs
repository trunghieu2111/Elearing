﻿namespace Home.Elearning.Permissions
{
    public static class ElearningPermissions
    {
        public const string GroupName = "Elearning";

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";
    }
}