﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Home.Elearning.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("Home.Elearning.TestBase")]
