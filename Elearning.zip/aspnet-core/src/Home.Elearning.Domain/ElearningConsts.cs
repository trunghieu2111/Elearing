﻿namespace Home.Elearning
{
    public static class ElearningConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}
