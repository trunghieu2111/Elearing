﻿namespace Home.Elearning.Settings
{
    public static class ElearningSettings
    {
        private const string Prefix = "Elearning";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}