﻿namespace Home.Elearning
{
    public static class ElearningDomainErrorCodes
    {
        /* You can add your business exception error codes here, as constants */
    }
}
