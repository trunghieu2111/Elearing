﻿using Volo.Abp.Localization;

namespace Home.Elearning.Localization
{
    [LocalizationResourceName("Elearning")]
    public class ElearningResource
    {

    }
}