﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Home.Elearning.Application.Tests")]
