﻿using AutoMapper;

namespace Home.Elearning
{
    public class ElearningApplicationAutoMapperProfile : Profile
    {
        public ElearningApplicationAutoMapperProfile()
        {
            /* You can configure your AutoMapper mapping configuration here.
             * Alternatively, you can split your mapping configurations
             * into multiple profile classes for a better organization. */
        }
    }
}
