﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Home.Elearning.EntityFrameworkCore.Tests")]
